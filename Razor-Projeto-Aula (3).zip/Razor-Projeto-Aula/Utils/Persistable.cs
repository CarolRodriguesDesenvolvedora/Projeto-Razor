﻿using Microsoft.Extensions.Configuration.CommandLine;
using System.Text.Json;

namespace Razor_Projeto_Aula.Utils
{
    internal class Persistable<T>
    {
        public void Store(string path, T item)
        {
            List<T> items = new List<T>();

            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                if (!string.IsNullOrWhiteSpace(json))
                {
                    try
                    {
                        items = JsonSerializer.Deserialize<List<T>>(json);
                    }
                    catch (InvalidOperationException ex)
                    {
                        Console.WriteLine("Arquivo estabelecimento não está no padrão! ");
                    }
                }
            }

            Console.WriteLine(items.Count);

            int newId = items.Count; 
            item. = newId++;

            items.Add(item);

            string updatedJson = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, updatedJson);
        }

        public List<T> Load(string path)
        {
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                if (!string.IsNullOrWhiteSpace(json))
                {

                    try
                    {
                        return JsonSerializer.Deserialize<List<T>>(json);
                    }
                    catch (InvalidOperationException ex)
                    {
                        Console.WriteLine("Não foi possível ler o arquivo " + ex.Message);
                    }

                }
            }

            return new List<T>();
        }

        public void Update(string path, Func<T, bool> predicate, T updatedItem)
        {
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                var items = JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();

                for (int i = 0; i < items.Count; i++)
                {
                    if (predicate(items[i]))
                    {
                        items[i] = updatedItem;
                        break;
                    }
                }

                string updatedJson = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(path, updatedJson);
            }
        }

        public void Delete(string path, Func<T, bool> predicate)
        {
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                var items = JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();

                items = items.Where(item => !predicate(item)).ToList();

                string updatedJson = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(path, updatedJson);
            }
        }
    }
}
