﻿using Razor_Projeto_Aula.Utils;

namespace Razor_Projeto_Aula.Models
{
    public class Motoboy
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string Salario { get; set; }
        public string Comissao { get; set; }

        public void store()
        {
            Persistable<Motoboy> persistable = new Persistable<Motoboy>();
            persistable.Store("./motoby.json", this);
        }
        public static List<Motoboy> load() //static = não retorna um objeto e sim da classe 
        {
            Persistable<Motoboy> persistable = new Persistable<Motoboy>();
            return persistable.Load("./motoboy.json");
        }

        public static void Delete(Func<Motoboy, bool> predicate) //predicate?
        {
            Persistable<Motoboy> persistable = new Persistable<Motoboy>();
            persistable.Delete("./motoby.json", predicate);
        }

        public static void Update(Func<Motoboy, bool> predicate, Motoboy updatedMotoboy)
        {
            Persistable<Motoboy> persistable = new Persistable<Motoboy>();
            persistable.Update("./motoboy.json", predicate, updatedMotoboy);
        }
    }
}
