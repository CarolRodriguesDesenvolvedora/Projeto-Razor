﻿using Razor_Projeto_Aula.Utils;

namespace Razor_Projeto_Aula.Models
{
    public class Produto
    {
        public string? Nome;
        public float? Preco;
        public int? Quantidade;
        public int Id { get; set; }

        public Produto() { }
        public Produto(string nomeProduto, float preco, int quantidade)

        { //nome recebe nomeProduto
            this.Nome = nomeProduto;
            this.Preco = preco;
            this.Quantidade = quantidade;
        }
        public void store()
        {
            Persistable<Produto> persistable = new Persistable<Produto>();
            Console.WriteLine(this.Nome);
            persistable.Store("./produto.json", this);
            /*
            string json = JsonSerializer.Serialize(this);
            using (StreamWriter sw = new StreamWriter("./cliente.json", append: true))
            {
                sw.WriteLine(json);
              //  sw.WriteLine(this.detalhes(json));
            }
            */
        }
        public static List<Produto> load() //static = não retorna um objeto e sim da classe 
        {
            Persistable<Produto> persistable = new Persistable<Produto>();
            return persistable.Load("./produto.json");
        }

        public static void Delete(Func<Produto, bool> predicate) //predicate?
        {
            Persistable<Produto> persistable = new Persistable<Produto>();
            persistable.Delete("./produto.json", predicate);
        }

        public static void Update(Func<Produto, bool> predicate, Produto updatedProduto)
        {
            Persistable<Produto> persistable = new Persistable<Produto>();
            persistable.Update("./produto.json", predicate, updatedProduto);
        }
    }
}
