﻿using Razor_Projeto_Aula.Utils;

namespace Razor_Projeto_Aula.Models
{
    public class Estabelecimento
    {
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Bairro { get; set; }
        public int Id { get; set; }

        public Estabelecimento(string Rua, int Numero, string Bairro)
        {
            this.Rua = Rua;
            this.Numero = Numero;
            this.Bairro = Bairro;
        }

        public void store()
        {
            Persistable<Estabelecimento> persistable = new Persistable<Estabelecimento>();
            persistable.Store("./endereco.json", this);
        }
        public static List<Estabelecimento> load() //static = não retorna um objeto e sim da classe 
        {
            Persistable<Estabelecimento> persistable = new Persistable<Estabelecimento>();
            return persistable.Load("./endereco.json");
        }
        public static void Delete(Func<Estabelecimento, bool> predicate) //predicate?
        {
            Persistable<Estabelecimento> persistable = new Persistable<Estabelecimento>();
            persistable.Delete("./endereco.json", predicate);
        }

        public static void Update(Func<Estabelecimento, bool> predicate, Estabelecimento updatedEndereco)
        {
            Persistable<Estabelecimento> persistable = new Persistable<Estabelecimento>();
            persistable.Update("./endereco.json", predicate, updatedEndereco);
        }
    }
}
