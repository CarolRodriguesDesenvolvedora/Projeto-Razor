using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_Projeto_Aula.Models;

namespace Razor_Projeto_Aula.Pages
{
    public class ProdutoModel : PageModel
    {
        public string nome { get; set; }
        public float preco { get; set; }
        public int quantidade { get; set; }



        public List<Produto> produtos { get; set; } = new List<Produto>();
        [BindProperty]
        public Produto novoProduto { get; set; }

        public void OnGet(int? id)
        {
            Console.WriteLine("listagem de produtos");
            produtos = Produto.load();

            if (id.HasValue)
            {
                List<Produto> produtosEditar = produtos.Where(c => c.Id == id.Value).ToList();

                var produtosSelecionado = produtosEditar.FirstOrDefault();

                if (produtosSelecionado != null)
                {
                    nome = produtosSelecionado.Nome;
               //     preco = produtosSelecionado.preco;
                //    quantidade = produtosSelecionado.quantidade;
                }
            }

        }

        public IActionResult OnPost(int? id)
        {
            
            Console.WriteLine(id);
            Console.WriteLine("Formul�rio enviado com sucesso");

            var produtoNome = Request.Form["nome"];

            var produtoPreco = Request.Form["preco"];

            var produtoQuantidade = Request.Form["quantidade"];

            Produto ProdutoModel = new Produto();
            ProdutoModel.Nome = produtoNome;
            ProdutoModel.Preco = float.Parse(produtoPreco);
            ProdutoModel.Quantidade = int.Parse(produtoQuantidade);
     

            ProdutoModel.store();
            
            return RedirectToPage();



        }
    }
}

