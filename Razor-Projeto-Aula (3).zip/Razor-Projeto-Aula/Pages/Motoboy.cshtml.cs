using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_Projeto_Aula.Models;

namespace Razor_Projeto_Aula.Pages
{
    public class MotoboyModel : PageModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string Salario { get; set; }
        public string Comissao { get; set; }

        public List<Motoboy> motoboys { get; set; } = new List<Motoboy>();

        [BindProperty]
        public Motoboy novoMotoboy { get; set; }

        public void OnGet(int? id)
        {
            motoboys = Motoboy.load();

            if (id.HasValue)
            {
                List<Motoboy> motoboysEditar = motoboys.Where(c => c.Id == id.Value).ToList();

                var motoboysSelecionado = motoboysEditar.FirstOrDefault();

                if (motoboysSelecionado != null)
                {
                    Nome = motoboysSelecionado.Nome;
                    Salario = motoboysSelecionado.Salario;
                    Comissao = motoboysSelecionado.Comissao;
                }
            }

        }

        public IActionResult OnPost(int? id)
        {
            Console.WriteLine(id);
            Console.WriteLine("Formul�rio enviado com sucesso");
            var motoboyNome = Request.Form["Nome"];

            var motobySalario = Request.Form["Salario"];

            var motoboyComissao = Request.Form["Comissao"];

            Motoboy MotoboyModel = new Motoboy();

            MotoboyModel.Nome = motoboyNome;
            MotoboyModel.Salario = motobySalario;
            MotoboyModel.Comissao = motoboyComissao;

            MotoboyModel.store();

            return RedirectToPage();



        }
    }
}
