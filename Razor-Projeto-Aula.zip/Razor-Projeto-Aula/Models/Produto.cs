﻿namespace Razor_Projeto_Aula.Models
{
    public class Produto
    {
        public string nome;
        public float preco;
        public int quantidade;

        public Produto(string nomeProduto, float preco, int quantidade)

        { //nome recebe nomeProduto
            this.nome = nomeProduto;
            this.preco = preco;
            this.quantidade = quantidade;
        }
    }
}
