﻿namespace Razor_Projeto_Aula.Models
{
    public class Estabelecimento
    {

        public string Nome { get; set; }
        public Endereco Endereco { get; set; }

    }
}
