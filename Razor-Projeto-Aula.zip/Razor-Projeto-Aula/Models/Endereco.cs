﻿namespace Razor_Projeto_Aula.Models
{
    public class Endereco
    {
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Bairro { get; set; }

        public Endereco(string Rua, int Numero, string Bairro)
        {
            this.Rua = Rua;
            this.Numero = Numero;
            this.Bairro = Bairro;
        }
    }
}
