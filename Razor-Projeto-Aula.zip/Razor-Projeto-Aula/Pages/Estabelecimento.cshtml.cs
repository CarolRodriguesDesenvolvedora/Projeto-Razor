using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_Projeto_Aula.Models;

namespace Razor_Projeto_Aula.Pages
{
    public class EstabelecimentoModel : PageModel
    {
        public string Nome { get; set; }
        public Endereco Endereco { get; set; }
    }
}
