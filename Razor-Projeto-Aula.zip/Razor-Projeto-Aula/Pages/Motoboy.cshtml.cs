using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razor_Projeto_Aula.Pages
{
    public class MotoboyModel : PageModel
    {
        public double Salario { get; set; }
        public double Comissao { get; set; }
    }
}
