using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razor_Projeto_Aula.Pages
{
    public class ProdutoModel : PageModel
    {
        public string nome { get; set; }
        public float preco { get; set; }
        public int quantidade { get; set; }
    }
}
