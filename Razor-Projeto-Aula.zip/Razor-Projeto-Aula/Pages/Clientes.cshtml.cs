using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_Projeto_Aula.Models;

namespace Razor_Projeto_Aula.Pages
{
    public class Clientes : PageModel
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public int ID { get; set; }

        /*[HttpPost]
        public IActionResult Create(Cliente cliente)
        {
            if (modelState.IsValid) 
            {
                return RedirectToAction("Index");
            }
            return View(cliente);
        }*/
        public List<Cliente> clientes { get; set; } = new List<Cliente>();
        [BindProperty]
        public Cliente novoCliente { get; set;}

        public void OnGet(int? id)
        {
            clientes = Cliente.load();

            if (id.HasValue)
            {
                List<Cliente> clientesEditar = clientes.Where(c => c.Id == id.Value).ToList();

                var clientesSelecionado = clientesEditar.FirstOrDefault();

                if (clientesSelecionado != null)
                {
                    Nome = clientesSelecionado.Nome;
                    Email = clientesSelecionado.Email;
                    Telefone = clientesSelecionado.Telefone;
                    ID = clientesSelecionado.Id;
                }
            }

        }

        public IActionResult OnPost(int? id)
        {
            Console.WriteLine(id);
            Console.WriteLine("Formul�rio enviado com sucesso");
            var clienteNome = Request.Form["Nome"];

            var clienteEmail = Request.Form["Email"];

            var clienteTelefone = Request.Form["Telefone"];

            Cliente clienteModel = new Cliente();

            clienteModel.Nome = clienteNome;
            clienteModel.Email = clienteEmail;
            clienteModel.Telefone = clienteTelefone;

            clienteModel.store();

            return RedirectToPage();



        }

    }
}
