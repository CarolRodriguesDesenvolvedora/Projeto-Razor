﻿namespace Razor_Projeto_Aula.Models
{
    public class Motoboy
    {
        public double Salario { get; set; }
        public double Comissao { get; set; }
    }
}
