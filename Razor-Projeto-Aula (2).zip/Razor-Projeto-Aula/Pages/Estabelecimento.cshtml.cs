using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_Projeto_Aula.Models;

namespace Razor_Projeto_Aula.Pages
{
    public class EstabelecimentoModel : PageModel
    {
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Bairro { get; set; }
        public int ID { get; set; }
        public int Id { get; set; }

        public List<EstabelecimentoModel> estabelecimentos { get; set; } = new List<EstabelecimentoModel>();
        [BindProperty]
        public EstabelecimentoModel novoEstabelecimento { get; set; }

        public void OnGet(int? id)
        {
            /*
            if (id.HasValue)
            {
                /*
              //  List<Estabelecimento> enderecoEditar = estabelecimentos.Where(c => c.id == id.Value).ToList();

            //    var enderecoSelecionado = enderecoEditar.FirstOrDefault();

                if (enderecoSelecionado != null)
                {
                    Rua = enderecoSelecionado.Rua;
                    Numero = enderecoSelecionado.Numero;
                    Bairro = enderecoSelecionado.Bairro;
                    ID = enderecoSelecionado.Id;
                }
        
             */

        }
        public IActionResult OnPost(int? id)
        {

            Console.WriteLine(id);
            Console.WriteLine("Formul�rio enviado com sucesso");

            var estabelecimentosRua = Request.Form["Nome da Rua"];

            var estabelecimentosNumero = Request.Form["N�mero do estabelecimento"];

            var estabelecimentosBairro = Request.Form["Bairro"];

            Estabelecimento EstabelecimentoModel = new Estabelecimento(estabelecimentosRua, int.Parse(estabelecimentosNumero), estabelecimentosBairro);

            EstabelecimentoModel.store();

            return RedirectToPage();



        }
    }
}
